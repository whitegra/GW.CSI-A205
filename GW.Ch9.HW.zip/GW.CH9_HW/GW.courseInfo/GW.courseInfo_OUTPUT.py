Python 3.11.5 (tags/v3.11.5:cce6ba9, Aug 24 2023, 14:38:34) [MSC v.1936 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
>>> 
= RESTART: C:/Users/graci/OneDrive/Desktop/CODING PROJECTS/COMPUTER_PROGRAMMING_FA24/GW.courseInfo.py
Enter the course ID: NT110
__________________________________
NT110 Instructor: Burke
NT110 Room #: 1244
NT110 Time: 11:00 a.m.
___________________________________
Look up another course? ('y/n'): y
Enter the course ID: CS101
__________________________________
CS101 Instructor: Haynes
CS101 Room #: 3004
CS101 Time: 8:00 a.m.
___________________________________
Look up another course? ('y/n'): n
