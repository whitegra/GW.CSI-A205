# im using the string library to generate the letters so I dont have to manually define the entire dictionary:
# https://docs.python.org/3/library/string.html

import string

# first to generate the letter codes
def generate_letter_codes():
    letters = string.ascii_letters  # this will import all letters uppercase and lowercase
    code_symbols = list("!✿1@2#❅3$4%5✈^6&7☁*890_-▲+={[}]|▥\\:;▣'<,>.?/~`≡♢🜃♢❂♥☢◍✯") # these are the symbols to be mapped to the letters
    codes = {letter: code_symbols[i] for i, letter in enumerate(letters)}
    return codes

#Define the encryption and decryption mappings
codes = generate_letter_codes()
decode_dict = {v: k for k, v in codes.items()}

# Encrypt file function
def encrypt_file(input_filename, encrypted_filename):

    with open(input_filename, 'r', encoding='utf-8') as input_file: #YOU HAVE TO SPECIFY ENCODING OR THE STR LIBRARY WONT WORK
        input_content = input_file.read()  #open and read the contents of the origional file to decrypt

    encrypted_content = ''.join(codes.get(char, char) for char in input_content)  # get the encryped content by converting the input content to the codes

    with open(encrypted_filename, 'w', encoding='utf-8') as encrypted_file: #opwn the encrypted file, and write the encrypted contents to the file
        encrypted_file.write(encrypted_content)  #write the contents to the file


# Decrypt file function
def decrypt_file(input_filename, output_filename):

    with open(input_filename, 'r', encoding='utf-8') as infile:
        content = infile.read()  #read the entire content of the file
    decrypted_content = ''.join(decode_dict.get(char, char) for char in content)  # Decrypt content
    with open(output_filename, 'w', encoding='utf-8') as outfile:
        outfile.write(decrypted_content)  #then write the decrypted content to output file

def main():
    while True:
        print("\nSelect an option:")
        print("1. Encrypt")
        print("2. Decrypt")
        print("3. Exit")
        
        choice = input("Enter your choice (1, 2, or 3): ")
        
        if choice == '1':
            # Encrypt a file
            input_filename = input("Enter the name of the file to encrypt: ")
            output_filename = input("Enter the name of the output encrypted file: ")
            encrypt_file(input_filename, output_filename)
        
        elif choice == '2':
            # Decrypt a file
            input_filename = input("Enter the name of the file to decrypt: ")
            output_filename = input("Enter the name of the output decrypted file: ")
            decrypt_file(input_filename, output_filename)
        
        elif choice == '3':
            break
        
        else:
            print("Invalid, try again. .")
        
        # Ask if the user wants to run the program again
        run_again = input("Run again? (y/n): ").lower()
        if run_again != 'y':
            break

#run the main function
if __name__ == "__main__":
    main()
