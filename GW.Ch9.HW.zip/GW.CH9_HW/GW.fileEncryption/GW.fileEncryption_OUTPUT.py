Python 3.11.5 (tags/v3.11.5:cce6ba9, Aug 24 2023, 14:38:34) [MSC v.1936 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
>>> 
= RESTART: C:\Users\graci\OneDrive\Desktop\CODING PROJECTS\COMPUTER_PROGRAMMING_FA24\GW.fileEncryption.py

Select an option:
1. Encrypt
2. Decrypt
3. Exit
Enter your choice (1, 2, or 3): 1
Enter the name of the file to encrypt: input_file.txt
Enter the name of the output encrypted file: output_file.txt
Run again? (y/n): y

Select an option:
1. Encrypt
2. Decrypt
3. Exit
Enter your choice (1, 2, or 3): 2
Enter the name of the file to decrypt: output_file.txt
Enter the name of the output decrypted file: decrypted_file.txt
Run again? (y/n): n
