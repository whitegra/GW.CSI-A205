def read_world_series_file(file_name):
    """
    purpose: to read the contents of the worldseries file, and put them in a dictionry.
    input: the file
    """
    # innitialize the dictionaries, the years with no winner, and the missing years from the file:
    team_wins = {}
    year_winner = {}
    start_year = 1903
    missing_years = {1904, 1994}

    with open(file_name, 'r') as file: #open the file for reading
        current_year = start_year #
        for line in file:
            team = line.strip()
            if current_year in missing_years:
                current_year += 1
                continue

            #update the year_winner dictionary with the winner and corresponding year they won
            year_winner[current_year] = team
            
            #now, count the winning teams 
            if team in team_wins:
                team_wins[team] += 1
            else:
                team_wins[team] = 1
            
            current_year += 1 #incriment the current year to get all the years and the winners

    return team_wins, year_winner #return the winning teams dict, and the year_winner dict

def main():
    #load the file, and call the function ot read the contents into the dictionary
    file_name = 'WorldSeriesWinners.txt'
    team_wins, year_winner = read_world_series_file(file_name)

    while True:
        try:
            print("___________________________________________________")
            year = int(input("Enter a year in the range 1903-2009: "))
            if year < 1903 or year > 2009:
                print("Year out of range. Try again") #in case the user enters a year that is out of the range
                continue
            if year in {1904, 1994}: #in case the user enters a missing year
                print(f"The World Series was not played in {year}.")
                continue

            winning_team = year_winner[year] #get the winning_team for the year entered
            win_count = team_wins[winning_team] #get the win count for that team
            print("_______________________________________________")
            print(f"For {year}, the {winning_team} won.")
            print(f"{winning_team} have won the World Series {win_count} times.")
            print("_______________________________________________")

        #HAVE TO INCLUDE the value error in case the input is not valid

        except ValueError:
            print("The year is not valid.")
        except KeyError:
            print("There are no contents for that year.")

        # Option to break the loop
        run_again = input("Run again? (y/n): ").strip().lower()
        if run_again != 'y':
            break

#run the main function
if __name__ == "__main__":
    main()

