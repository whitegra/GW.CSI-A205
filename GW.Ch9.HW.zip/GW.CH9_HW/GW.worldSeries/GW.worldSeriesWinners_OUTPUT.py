Python 3.11.5 (tags/v3.11.5:cce6ba9, Aug 24 2023, 14:38:34) [MSC v.1936 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
>>> 
= RESTART: C:/Users/graci/OneDrive/Desktop/CODING PROJECTS/COMPUTER_PROGRAMMING_FA24/GW.worldSeriesWinners.py
___________________________________________________
Enter a year in the range 1903-2009: 1920
_______________________________________________
For 1920, the New York Giants won.
New York Giants have won the World Series 4 times.
_______________________________________________
Run again? (y/n): y
___________________________________________________
Enter a year in the range 1903-2009: 1994
The World Series was not played in 1994.
___________________________________________________
Enter a year in the range 1903-2009: 1993
_______________________________________________
For 1993, the Atlanta Braves won.
Atlanta Braves have won the World Series 1 times.
_______________________________________________
Run again? (y/n): n
