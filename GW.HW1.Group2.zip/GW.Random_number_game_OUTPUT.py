Python 3.11.5 (tags/v3.11.5:cce6ba9, Aug 24 2023, 14:38:34) [MSC v.1936 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.

= RESTART: C:/Users/graci/OneDrive/Desktop/CODING PROJECTS/COMPUTER_PROGRAMMING_FA24/GW.Random_number_game.py
Guess a number between 1 and 100: 50
Incorrect. The magic number is greater than 50
Guess a number between 1 and 100: 60
Incorrect. The magic number is greater than 60
Guess a number between 1 and 100: 70
Incorrect. The magic number is greater than 70
Guess a number between 1 and 100: 80
Incorrect. The magic number is greater than 80
Guess a number between 1 and 100: 90
Incorrect. The magic number is greater than 90
Guess a number between 1 and 100: 99
Incorrect. The magic number is less than 99
Guess a number between 1 and 100: 98
Incorrect. The magic number is less than 98
Guess a number between 1 and 100: 97
Incorrect. The magic number is less than 97
Guess a number between 1 and 100: 96
Incorrect. The magic number is less than 96
Guess a number between 1 and 100: 95
Incorrect. The magic number is less than 95
Guess a number between 1 and 100: 94
Incorrect. The magic number is less than 94
Guess a number between 1 and 100: 93
Incorrect. The magic number is less than 93
Guess a number between 1 and 100: 92
Correct! The magic number is: 92
Game Summary:
-----------------
The magic number was: 92
Number of Incorrect Guesses: 12
Total number of Attempts: 13
------------------
Would you like to play again? 'y' for yes, 'n' to exit: y
Guess a number between 1 and 100: 50
Incorrect. The magic number is greater than 50
Guess a number between 1 and 100: 60
Incorrect. The magic number is less than 60
Guess a number between 1 and 100: 55
Incorrect. The magic number is greater than 55
Guess a number between 1 and 100: 56
Incorrect. The magic number is greater than 56
Guess a number between 1 and 100: 58
Incorrect. The magic number is greater than 58
Guess a number between 1 and 100: 59
Correct! The magic number is: 59
Game Summary:
-----------------
The magic number was: 59
Number of Incorrect Guesses: 5
Total number of Attempts: 6
------------------
Would you like to play again? 'y' for yes, 'n' to exit: n
