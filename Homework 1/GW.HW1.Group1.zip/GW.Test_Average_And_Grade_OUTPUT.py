Python 3.11.5 (tags/v3.11.5:cce6ba9, Aug 24 2023, 14:38:34) [MSC v.1936 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
>>> 
= RESTART: C:/Users/graci/OneDrive/Desktop/CODING PROJECTS/COMPUTER_PROGRAMMING_FA24/GW.Test_Average_And_Grade.py
Enter score: 91
Enter score: 88
Enter score: 70
Enter score: 62
Enter score: 50
__________________________
student letter grades:
Score 91.0  = Grade A!
__________________________
__________________________
student letter grades:
Score 88.0  = Grade B
__________________________
__________________________
student letter grades:
Score 70.0  = Grade C
__________________________
__________________________
student letter grades:
Score 62.0  = Grade D
__________________________
__________________________
student letter grades:
Score 50.0  = Grade F
__________________________
______________________________
Average Score: 72.2
Average Letter Grade: C
______________________________
Run again? Enter 'y' for yes, or 'n' to exit.n
