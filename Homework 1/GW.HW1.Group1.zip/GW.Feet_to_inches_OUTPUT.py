Python 3.11.5 (tags/v3.11.5:cce6ba9, Aug 24 2023, 14:38:34) [MSC v.1936 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
>>> 
================================================= RESTART: C:/Users/graci/AppData/Local/Programs/Python/Python311/F/GW.Feet_to_inches.py ================================================
To begin, enter 'f' for inches to feet, or 'i' for feet to inches: f
Enter the number of inches to be converted to feet: 12
12.0 inches = 1.0 feet
Run program again? Enter 'y' for yes, or 'n' to exit: y
To begin, enter 'f' for inches to feet, or 'i' for feet to inches: i
Enter the number of feet to be converted to inches: 36
36.0 feet = 432.0 inches
Run program again? Enter 'y' for yes, or 'n' to exit: n
