Python 3.11.5 (tags/v3.11.5:cce6ba9, Aug 24 2023, 14:38:34) [MSC v.1936 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
>>> 
= RESTART: C:/Users/graci/OneDrive/Desktop/CODING PROJECTS/COMPUTER_PROGRAMMING_FA24/GW.Drivers.Exam.py
Congrats, you passed!
_______________________
Number of correct answers: 18
Questions answered correctly: [(2, 'C'), (4, 'A'), (5, 'D'), (6, 'B'), (7, 'C'), (8, 'A'), (9, 'C'), (10, 'B'), (11, 'A'), (12, 'D'), (13, 'C'), (14, 'A'), (15, 'D'), (16, 'C'), (17, 'B'), (18, 'B'), (19, 'D'), (20, 'A')]
Number of incorrect answers: 2
Questions answered incorrect: [(1, 'B'), (3, 'D')]
_______________________
Would you like to re-grade?: 'y/n': n
