# innitializing the options
LOOK_UP = 1
ADD = 2
CHANGE = 3
DELETE = 4
QUIT = 5


def main():
    # innitialize the birthday dict and choices to zero
    birthdays = {}
    choice = 0
    
    while choice != QUIT:
        choice = get_menu_choice()
        if choice == LOOK_UP:
            look_up(birthdays)
        elif choice == ADD:
            add(birthdays)
        elif choice == CHANGE:
            change(birthdays)
        elif choice == DELETE:
            delete(birthdays)


def get_menu_choice():
    print()
    print('Choices for Friends and Their Birthdays Lookup')
    print('--------------------------')
    print('1. Look up a birthday')
    print('2. Add a new birthday')
    print('3. Change a birthday')
    print('4. Delete a birthday')
    print('5. Quit the program')
    print()

    choice = int(input('Enter your choice: '))

    # make sure the user's choice is valid:
    while choice < LOOK_UP or choice > QUIT:
        choice = int(input('Enter a valid choice: '))
    return choice

def look_up(birthdays):
    # get a name to look up, if its not in the dict then its 'not found'
    name = input('Enter the name to look up: ')
    print(birthdays.get(name, 'Not found.'))


def add(birthdays):
    name = input('Enter the name: ')
    bday = input('Enter the birthday: ')

    #if the name dosent exist in the dict, then add it:
    if name not in birthdays:
        birthdays[name] = bday
    else:
        print('That name/birthday already exists.')

def change(birthdays):
    name = input('Enter the name: ')

    if name in birthdays:
        # Get a new birthday.
        bday = input('Enter the new birthday: ')

        # Update the entry.
        birthdays[name] = bday
    else:
        print('That name is not found.')


def delete(birthdays):

    name = input('Enter the name: ')

    #if the name is found, then delete it.
    if name in birthdays:
        del birthdays[name]
    else:
        print('That name is not found.')

# calling the main function
main()
