
# Define the baseball and basketball teams with SEVEN and SIX members.
baseball = set(['Jodi', 'Carmen', 'Aida', 'Alicia', 'Larry', 'Gertrude', 'Max'])
basketball = set(['Eva', 'Carmen', 'Alicia', 'Sarah', 'Gertrude', 'Eddison'])

# print te students on the basketball team:
print('These are the students on the baseball team:')
for name in baseball:
    print(name)

print()  #this is for spacing ?

# print the students on the basketball team
print('These are the students on the basketball team:')
for name in basketball:
    print(name)

print() 

#the intersection for tudents oon both teams
print('The following students play both baseball and basketball:')
for name in baseball.intersection(basketball):
    print(name)

print()  

#union of teams (students who play one not the other):
print('These students play either baseball or basketball:')
for name in baseball.union(basketball):
    print(name)

print()  

#difference (students who play baseball not basketball)
print('The following students play baseball, but not basketball:')
for name in baseball.difference(basketball):
    print(name)

print()  

#difference of students who play basketball but not baseball
print('The following students play basketball, but not baseball:')
for name in basketball.difference(baseball):
    print(name)

print() 

#symmetric difference (people who play one sport only)
print('The following students play one sport, but not both:')
for name in baseball.symmetric_difference(basketball):
    print(name)
