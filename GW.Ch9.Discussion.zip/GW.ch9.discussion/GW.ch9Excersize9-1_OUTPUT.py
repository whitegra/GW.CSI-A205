Python 3.11.5 (tags/v3.11.5:cce6ba9, Aug 24 2023, 14:38:34) [MSC v.1936 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
>>> 
= RESTART: C:/Users/graci/OneDrive/Desktop/CODING PROJECTS/COMPUTER_PROGRAMMING_FA24/GW.ch9Excerise9-1.py
Enter the number of cards to deal: 5
5 of Spades
8 of Hearts
7 of Clubs
7 of Hearts
Jack of Hearts
_______________________________________________
The card value of this hand: 37
_______________________________________________
Deal again?: (y/n)y
Enter the number of cards to deal: 3
8 of Clubs
8 of Spades
4 of Hearts
_______________________________________________
The card value of this hand: 20
_______________________________________________
Deal again?: (y/n)n
