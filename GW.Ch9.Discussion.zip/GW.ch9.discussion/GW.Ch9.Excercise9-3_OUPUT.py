Python 3.11.5 (tags/v3.11.5:cce6ba9, Aug 24 2023, 14:38:34) [MSC v.1936 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.

= RESTART: C:/Users/graci/OneDrive/Desktop/CODING PROJECTS/COMPUTER_PROGRAMMING_FA24/GW.Ch9.Excercise9-3.py
These are the students on the baseball team:
Aida
Larry
Alicia
Gertrude
Max
Carmen
Jodi

These are the students on the basketball team:
Alicia
Eddison
Sarah
Gertrude
Eva
Carmen

The following students play both baseball and basketball:
Gertrude
Carmen
Alicia

These students play either baseball or basketball:
Aida
Larry
Alicia
Eddison
Sarah
Gertrude
Eva
Max
Carmen
Jodi

The following students play baseball, but not basketball:
Aida
Larry
Max
Jodi

The following students play basketball, but not baseball:
Eva
Eddison
Sarah

The following students play one sport, but not both:
Aida
Larry
Eddison
Sarah
Eva
Max
Jodi
