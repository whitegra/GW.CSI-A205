Python 3.11.5 (tags/v3.11.5:cce6ba9, Aug 24 2023, 14:38:34) [MSC v.1936 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.

= RESTART: C:/Users/graci/OneDrive/Desktop/CODING PROJECTS/COMPUTER_PROGRAMMING_FA24/GW.PersonalinfoClass.MAIN.py
Enter the name of person 1: Bob
Enter the age of person 1: 56
Enter the address of person 1: 100 North Street
Enter the phone number for person 1: (317)563-9876
Enter the name of person 2: Sue
Enter the age of person 2: 18
Enter the address of person 2: 4567 South Ave
Enter the phone number for person 2: (317)555-5555
Enter the name of person 3: Larry
Enter the age of person 3: 89
Enter the address of person 3: 1212 East Ct
Enter the phone number for person 3: (327)888-8888
________________________________________________

 INFORMATION FOR PERSON #1: 

________________________________________________
name : Bob

age : 56

address : 100 North Street

phone number : (317)563-9876

________________________________________________

 INFORMATION FOR PERSON #1: 

________________________________________________
name : Sue

age : 18

address : 4567 South Ave

phone number : (317)555-5555

________________________________________________

 INFORMATION FOR PERSON #1: 

________________________________________________
name : Larry

age : 89

address : 1212 East Ct

phone number : (327)888-8888

