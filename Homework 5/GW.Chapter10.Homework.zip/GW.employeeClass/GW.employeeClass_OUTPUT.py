Python 3.11.5 (tags/v3.11.5:cce6ba9, Aug 24 2023, 14:38:34) [MSC v.1936 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
>>> 
= RESTART: C:/Users/graci/OneDrive/Desktop/CODING PROJECTS/COMPUTER_PROGRAMMING_FA24/GW.employeeClass.MAIN.py
Enter the name for employee 1: Bob
Enter the ID for employee 1: 23456
Enter the department for employee 1: Science
Enter the job title for employee 1: Teacher
Enter the name for employee 2: Susan
Enter the ID for employee 2: 12345
Enter the department for employee 2: Math
Enter the job title for employee 2: Tutor
Enter the name for employee 3: Ronald
Enter the ID for employee 3: 54321
Enter the department for employee 3: Chemistry
Enter the job title for employee 3: Professor
________________________________________________

 INFORMATION FOR EMPLOYEE #1: 

________________________________________________
name : Bob

age : 23456

address : Science

phone number : Teacher

________________________________________________

 INFORMATION FOR EMPLOYEE #1: 

________________________________________________
name : Susan

age : 12345

address : Math

phone number : Tutor

________________________________________________

 INFORMATION FOR EMPLOYEE #1: 

________________________________________________
name : Ronald

age : 54321

address : Chemistry

phone number : Professor

