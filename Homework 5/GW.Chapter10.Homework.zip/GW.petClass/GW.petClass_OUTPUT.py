Python 3.11.5 (tags/v3.11.5:cce6ba9, Aug 24 2023, 14:38:34) [MSC v.1936 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
>>> 
= RESTART: C:/Users/graci/OneDrive/Desktop/CODING PROJECTS/COMPUTER_PROGRAMMING_FA24/GW.petClass.MAIN.py
__________________________________
Enter the name of your pet: Max
Enter the type of animal your pet is: Dog
Enter the age of your pet (in years): 12
__________________________________

Your pet's information: 
__________________________________
Pet name: Max
Pet type: Dog
Pet age: 12
Would you like to enter information for another pet? (y/n): y
__________________________________
Enter the name of your pet: Ruby
Enter the type of animal your pet is: Cat
Enter the age of your pet (in years): 3
__________________________________

Your pet's information: 
__________________________________
Pet name: Ruby
Pet type: Cat
Pet age: 3
Would you like to enter information for another pet? (y/n): n
