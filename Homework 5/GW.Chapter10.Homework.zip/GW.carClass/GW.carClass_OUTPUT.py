Python 3.11.5 (tags/v3.11.5:cce6ba9, Aug 24 2023, 14:38:34) [MSC v.1936 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
>>> 
= RESTART: C:/Users/graci/OneDrive/Desktop/CODING PROJECTS/COMPUTER_PROGRAMMING_FA24/GW.carClass.MAIN.py
________________________________________
Enter the model (in year) of your car: 2024
Enter the make of your car: Toyota

ACCELERATING
Current speed of 2024 Toyota = 5
_______________________________________________________________________
Current speed of 2024 Toyota = 10
_______________________________________________________________________
Current speed of 2024 Toyota = 15
_______________________________________________________________________
Current speed of 2024 Toyota = 20
_______________________________________________________________________
Current speed of 2024 Toyota = 25
_______________________________________________________________________

BREAKING
Current breaking speed of 2024 Toyota = 20
_______________________________________________________________________
Current breaking speed of 2024 Toyota = 15
_______________________________________________________________________
Current breaking speed of 2024 Toyota = 10
_______________________________________________________________________
Current breaking speed of 2024 Toyota = 5
_______________________________________________________________________
Current breaking speed of 2024 Toyota = 0
_______________________________________________________________________

Would you like to run again? (y/n): n
