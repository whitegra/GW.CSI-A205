Python 3.11.5 (tags/v3.11.5:cce6ba9, Aug 24 2023, 14:38:34) [MSC v.1936 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
>>> 
= RESTART: C:/Users/graci/OneDrive/Desktop/CODING PROJECTS/COMPUTER_PROGRAMMING_FA24/GW.Ch8.Problem2&3.py
Choose which operation you would like to complete:
'W' for average words per sentence
'L' for lowercase count
'U' for uppercase count
'N' for number count
'A' for ALL OF THE ABOVE
Enter your choice: a
______________________________________
Average words per sentence: 55.785714285714285
______________________________________
Lowercase count: 1228
______________________________________
Uppercase count: 29
______________________________________
Number count: 30
______________________________________
Would you like to run this program again?: 'y/n': n
n
