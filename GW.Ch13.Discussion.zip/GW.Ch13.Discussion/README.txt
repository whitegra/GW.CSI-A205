README:

For these assignments, I was not sure how to submit sample outputs since they are GUI programs. They should all run as expected though. Also I ran out of time towards the end so some of the programs are pretty much the same as the example ones provided. Also I combined the charts into one program. 