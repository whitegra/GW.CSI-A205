Python 3.11.5 (tags/v3.11.5:cce6ba9, Aug 24 2023, 14:38:34) [MSC v.1936 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
>>> 
= RESTART: C:/Users/graci/OneDrive/Desktop/CODING PROJECTS/COMPUTER_PROGRAMMING_FA24/GW.Midterm.Problem#3.py
Chose which conversion: mm/dd/yy (1), or Month day , year (2)?: 2
Enter the date you want to convert: March 18, 2018
______________________________________________
3/18/2018
______________________________________________
Make another conversion? (y/n): y
Chose which conversion: mm/dd/yy (1), or Month day , year (2)?: 1
Enter the date you want to convert: 3/18/2018
______________________________________________
March, 18, 2018
______________________________________________
Make another conversion? (y/n): n
