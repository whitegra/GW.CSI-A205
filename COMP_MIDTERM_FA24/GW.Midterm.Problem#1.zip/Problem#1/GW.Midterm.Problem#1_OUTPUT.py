Python 3.11.5 (tags/v3.11.5:cce6ba9, Aug 24 2023, 14:38:34) [MSC v.1936 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
>>> 
= RESTART: C:/Users/graci/OneDrive/Desktop/CODING PROJECTS/COMPUTER_PROGRAMMING_FA24/GW.Midterm.Problem#1.py
Enter the sales for weekday Monday: 3000
Enter the hours worked for day Monday: 13
Total hours: 13.0
Total bonuses: 3.9
Enter the sales for weekday Tuesday: 20
Enter the hours worked for day Tuesday: 5
Total hours: 18.0
Total bonuses: 3.9099999999999997
Enter the sales for weekday Wednesday: 90
Enter the hours worked for day Wednesday: 12
Total hours: 30.0
Total bonuses: 4.018
Enter the sales for weekday Thursday: 730
Enter the hours worked for day Thursday: 9
Total hours: 39.0
Total bonuses: 4.675
Enter the sales for weekday Friday: 56
Enter the hours worked for day Friday: 3
Total hours: 42.0
Total bonuses: 4.6918
Enter the sales for weekday Saturday: 10000
Enter the hours worked for day Saturday: 13
Total hours: 55.0
Total bonuses: 30.6918
Enter the sales for weekday Sunday: 40000
Enter the hours worked for day Sunday: 9
Total hours: 64.0
Total bonuses: 102.6918
