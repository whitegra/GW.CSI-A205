Python 3.11.5 (tags/v3.11.5:cce6ba9, Aug 24 2023, 14:38:34) [MSC v.1936 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
>>> 
= RESTART: C:/Users/graci/OneDrive/Desktop/CODING PROJECTS/COMPUTER_PROGRAMMING_FA24/GW.World.Champion.Winners.py
Enter a world series team: Boston Red Socks 
The team Boston Red Socks  won the championship a total of 0 times
Would you like to enter a new team? ('y/n'): y
Enter a world series team: Boston Red Sox
The team Boston Red Sox won the championship a total of 6 times
Would you like to enter a new team? ('y/n'): n
