Python 3.11.5 (tags/v3.11.5:cce6ba9, Aug 24 2023, 14:38:34) [MSC v.1936 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
>>> 
= RESTART: C:/Users/graci/OneDrive/Desktop/CODING PROJECTS/COMPUTER_PROGRAMMING_FA24/GW.7-7.py
Enter the number of students: 10
student# 1: fees paid = $2277
student# 2: fees paid = $1771
student# 3: fees paid = $1771
student# 4: fees paid = $253
student# 5: fees paid = $759
student# 6: fees paid = $3795
student# 7: fees paid = $1518
student# 8: fees paid = $2277
student# 9: fees paid = $1518
student# 10: fees paid = $3036
